package com.warforge;

import java.util.Random;

import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkGenerator;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.feature.WorldGenMinable;
import net.minecraftforge.fml.common.IWorldGenerator;

public class OreWorldGen implements IWorldGenerator {

    private final WorldGenMinable[] generators =
        new WorldGenMinable[ModContent.ORE_BLOCKS.length];

    private static final int[] VEIN_SIZES = {7, 7, 6, 5, 4};
    private static final int[] ATTEMPTS = {10, 8, 6, 4, 3};
    private static final int[] MAX_HEIGHTS = {64, 48, 32, 24, 16};

    public OreWorldGen() {
        for (int i = 0; i < generators.length; i++) {
            IBlockState state =
                ModContent.ORE_BLOCKS[i].getDefaultState();

            generators[i] = new WorldGenMinable(
                state, VEIN_SIZES[i]
            );
        }
    }

    @Override
    public void generate(
        Random random,
        int chunkX,
        int chunkZ,
        World world,
        IChunkGenerator chunkGenerator,
        IChunkProvider chunkProvider
    ) {
        if (world.isRemote || !world.provider.isSurfaceWorld()) {
            return;
        }

        for (int i = 0; i < generators.length; i++) {
            for (int n = 0; n < ATTEMPTS[i]; n++) {
                int x = chunkX * 16 + random.nextInt(16);
                int y = 4 + random.nextInt(MAX_HEIGHTS[i] - 3);
                int z = chunkZ * 16 + random.nextInt(16);

                generators[i].generate(
                    world, random, new BlockPos(x, y, z)
                );
            }
        }
    }
}
