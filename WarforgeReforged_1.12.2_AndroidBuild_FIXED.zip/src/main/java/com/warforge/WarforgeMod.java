package com.warforge;

import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod(
    modid = WarforgeMod.MODID,
    name = WarforgeMod.NAME,
    version = WarforgeMod.VERSION
)
@Mod.EventBusSubscriber(modid = WarforgeMod.MODID)
public class WarforgeMod {

    public static final String MODID = "warforge";
    public static final String NAME = "Warforge: Reforged";
    public static final String VERSION = "1.0.0";

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        GameRegistry.registerWorldGenerator(
            new OreWorldGen(), 0
        );
    }

    @SubscribeEvent
    public static void registerBlocks(
        RegistryEvent.Register<Block> event
    ) {
        event.getRegistry().registerAll(
            ModContent.BLOCKS.toArray(
                new Block[ModContent.BLOCKS.size()]
            )
        );
    }

    @SubscribeEvent
    public static void registerItems(
        RegistryEvent.Register<Item> event
    ) {
        event.getRegistry().registerAll(
            ModContent.ITEMS.toArray(
                new Item[ModContent.ITEMS.size()]
            )
        );

        for (Block block : ModContent.BLOCKS) {
            ItemBlock itemBlock = new ItemBlock(block);
            itemBlock.setRegistryName(block.getRegistryName());
            event.getRegistry().register(itemBlock);
        }
    }
}
