WARFORGE: REFORGED — исходники мода для Minecraft 1.12.2
========================================================

ВАЖНО: это исходный код-пакет, который нужно наложить на Forge MDK 1.12.2.
Файл .jar пока не собран, а текстуры и рецепты — следующий этап разработки.

В первой версии есть:
- 5 рудных блоков: ruby, sapphire, mithril, obsidianite, dragonite;
- 8 сплавов;
- 8 мечей;
- 32 предмета брони (8 комплектов по 4 части);
- генерация руд в обычном мире.

Требования:
- Minecraft Forge 1.12.2, рекомендуемая сборка 14.23.5.2859;
- JDK 8 (64-bit);
- компьютер с Windows/macOS/Linux для сборки.

Установка среды:
1. Скачай Forge MDK для Minecraft 1.12.2 с официальной страницы:
   https://files.minecraftforge.net/net/minecraftforge/forge/index_1.12.2.html
2. Распакуй MDK в отдельную папку проекта.
3. Скопируй папки src из этого архива в папку MDK, объединив их.
4. В src/main/java должен быть пакет com/warforge.
5. В build.gradle из MDK установи archivesBaseName = 'warforge'.
6. Запусти подготовку рабочего пространства по инструкции для выбранной IDE.
   Для старого ForgeGradle 2.3 команды зависят от версии MDK; часто используются
   gradlew setupDecompWorkspace и gradlew eclipse либо gradlew idea.
7. Запусти тестовый клиент через IDE или gradlew runClient.
8. Собери мод командой gradlew build.
9. Готовый JAR ищи в build/libs и скопируй его в .minecraft/mods.

Проверка:
- Создай НОВЫЙ мир после установки мода: новые руды не появляются в уже
  сгенерированных чанках.
- Если сборка не проходит, проверь, что используется JDK 8, а не Java 17/21.
- Это стартовый каркас: рецепты, локализация, текстуры и модели будут добавлены
  следующим этапом.

ID предметов используют префикс warforge, например:
warforge:dragon_steel_sword
warforge:mithril_steel_helmet
warforge:dragonite_ore

Android build: см. ANDROID_BUILD_RU.txt. Добавлены JSON-рецепты и workflow облачной сборки GitHub Actions.
