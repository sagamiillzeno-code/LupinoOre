package com.warforge;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemSword;
import net.minecraftforge.common.util.EnumHelper;

public final class ModContent {
    public static final List<Block> BLOCKS = new ArrayList<Block>();
    public static final List<Item> ITEMS = new ArrayList<Item>();

    public static final String[] ORES = {
        "ruby", "sapphire", "mithril", "obsidianite", "dragonite"
    };

    public static final String[] ALLOYS = {
        "crimson_steel", "sapphire_alloy", "mithril_steel",
        "obsidian_alloy", "dragon_steel", "storm_alloy",
        "void_steel", "warforged_alloy"
    };

    public static final Block[] ORE_BLOCKS = new Block[ORES.length];
    public static final Item[] ORE_ITEMS = new Item[ORES.length];
    public static final Item[] ALLOY_ITEMS = new Item[ALLOYS.length];
    public static final ItemSword[] SWORDS = new ItemSword[ALLOYS.length];
    public static final ItemArmor[][] ARMOR =
        new ItemArmor[ALLOYS.length][4];

    private static final String[] ARMOR_NAMES = {
        "helmet", "chestplate", "leggings", "boots"
    };

    private static final EntityEquipmentSlot[] ARMOR_SLOTS = {
        EntityEquipmentSlot.HEAD,
        EntityEquipmentSlot.CHEST,
        EntityEquipmentSlot.LEGS,
        EntityEquipmentSlot.FEET
    };

    static {
        for (int i = 0; i < ORES.length; i++) {
            String name = ORES[i];

            Block block = new Block(Material.ROCK);
            block.setHardness(3.0F + i * 0.3F);
            block.setResistance(5.0F + i);
            block.setHarvestLevel("pickaxe", i < 2 ? 2 : 3);
            block.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
            block.setRegistryName(WarforgeMod.MODID, name + "_ore");
            block.setUnlocalizedName(
                WarforgeMod.MODID + "." + name + "_ore"
            );

            ORE_BLOCKS[i] = block;
            BLOCKS.add(block);

            ORE_ITEMS[i] = item(name + "_gem", 64);
        }

        for (int i = 0; i < ALLOYS.length; i++) {
            String alloy = ALLOYS[i];

            ALLOY_ITEMS[i] = item(alloy + "_ingot", 64);

            Item.ToolMaterial tool = EnumHelper.addToolMaterial(
                "WARFORGE_" + alloy.toUpperCase(),
                Math.min(4 + i / 2, 8),
                900 + i * 450,
                7.0F + i * 0.65F,
                5.0F + i * 1.15F,
                12 + i * 2
            );

            ItemSword sword = new ItemSword(tool);
            sword.setRegistryName(
                WarforgeMod.MODID, alloy + "_sword"
            );
            sword.setUnlocalizedName(
                WarforgeMod.MODID + "." + alloy + "_sword"
            );
            sword.setCreativeTab(CreativeTabs.COMBAT);

            SWORDS[i] = sword;
            ITEMS.add(sword);

            ItemArmor.ArmorMaterial armor =
                EnumHelper.addArmorMaterial(
                    "WF_" + alloy.toUpperCase(),
                    WarforgeMod.MODID + ":" + alloy,
                    28 + i * 5,
                    new int[] {
                        2 + i / 2, 5 + i, 6 + i, 2 + i / 2
                    },
                    10 + i * 2,
                    net.minecraft.init.SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND,
                    1.0F + i * 0.2F
                );

            for (int slot = 0; slot < 4; slot++) {
                String armorName = alloy + "_" + ARMOR_NAMES[slot];

                ItemArmor piece = new ItemArmor(
                    armor, slot, ARMOR_SLOTS[slot]
                );
                piece.setRegistryName(
                    WarforgeMod.MODID, armorName
                );
                piece.setUnlocalizedName(
                    WarforgeMod.MODID + "." + armorName
                );
                piece.setCreativeTab(CreativeTabs.COMBAT);

                ARMOR[i][slot] = piece;
                ITEMS.add(piece);
            }
        }
    }

    private static Item item(String name, int stackSize) {
        Item item = new Item();
        item.setMaxStackSize(stackSize);
        item.setRegistryName(WarforgeMod.MODID, name);
        item.setUnlocalizedName(WarforgeMod.MODID + "." + name);
        item.setCreativeTab(CreativeTabs.MATERIALS);
        ITEMS.add(item);
        return item;
    }

    private ModContent() {
    }
}
